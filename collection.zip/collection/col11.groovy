def a=2,b=12
10.times({print "\t"+(it+1)*a})
print "\n"
(1..10).each{print "\t"+ it*12}
