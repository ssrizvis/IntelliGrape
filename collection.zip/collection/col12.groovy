List l=('a'..'z')
println l
l.each({
    if(it>'j')
    print " "+it
})