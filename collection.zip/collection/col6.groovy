List l=[1,2,3,"element1",0.3,[2,4,6],0..10];
l.each({ 
print it.getClass()
print "\n"
})
l.get(6).get(9)