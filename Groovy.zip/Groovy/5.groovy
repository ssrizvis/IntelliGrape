(1..10).each{ 
println "3*${it}=${3*it}"} 