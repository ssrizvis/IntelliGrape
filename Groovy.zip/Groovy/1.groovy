class GroovyClass
{
    String name;
    int age;
    char gender;
    String add;
    public void getdata()
    {
        prinln("Enter Your Name : ");
        
        
    }
}