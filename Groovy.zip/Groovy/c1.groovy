List l=[]
l[11] = "myelement" 
println l[11] 
println l.get(5) 
println l 