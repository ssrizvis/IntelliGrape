for(int i=1; i<=8; i=i*2)
{
    i.times({print("*")})
    println();
}