List l=[null]
if(l) { println "test evaluated to true inside if" } 